#include "cachelab.h"
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <unistd.h>
#include <getopt.h>
/* 20220312 Junhyeok Park */

//cache struct: sets - lines - {valid,tag,lru}
typedef struct{
    bool valid;
    int tag;
    int lru;
} line_t;

typedef struct{
    line_t* lines;
} set_t;

typedef struct{
    set_t* sets;
} cache_t;

//initialize
cache_t cache = {};

//global variables
int s_bit=0, b_bit=0;
int S=0, E=0, B=0;
char* TraceFile=NULL;
int HitCount=0, MissCount=0, EvictionCount=0;
unsigned long long int LRUCounter = 1;

void ParseTrace();
void Simulate(int address);
void FreeCache();

//cache init; dynamic allocation and initialize
void InitCache(){
    cache.sets = (set_t*)malloc(sizeof(set_t) * S);
    for (int i=0; i<S; i++){
        cache.sets[i].lines = (line_t*)malloc(sizeof(line_t)*E);
        for (int j=0; j<E; j++){
            cache.sets[i].lines[j].valid=0;
            cache.sets[i].lines[j].tag=0;
            cache.sets[i].lines[j].lru=0;
        }
    }
}

//Parse Trace: read trace file, simulate cache
void ParseTrace(){
    FILE* traceFile = fopen(TraceFile, "r");
    char cmd;
    int address;
    int size;
    while(fscanf(traceFile, " %c %x,%d", &cmd, &address, &size)!=EOF){
        //'I' line is ignored
        switch(cmd){
            case 'L':
                Simulate(address);
                break;
            case 'S':
                Simulate(address);
                break;
            case 'M':
                //simulate twice
                Simulate(address);
                Simulate(address);
                break;
            default:
                break;
        }
    }
    fclose(traceFile);
}

//simulating cache
void Simulate(int address){
    //extract information from address
    size_t setIndex = (address >> b_bit) & (0x7fffffff>>(31-s_bit));
    size_t tag = (address >> (s_bit+b_bit)) & (0x7fffffff);
    //set 
    set_t set_c = cache.sets[setIndex];

    //cache hit
    for (int i=0; i < E ; i++){
        line_t line_c = set_c.lines[i];
        if (!line_c.valid) {
            continue;
        }
        if(tag!=line_c.tag){
            continue;
        }
        LRUCounter++;
        HitCount++;
        set_c.lines[i].lru=LRUCounter;
        return;
    }

    //cache miss
    MissCount++;

    //replace line based on LRU
    unsigned int evictionLine = 0;
    unsigned long long int evictionLRU = ULONG_MAX; 
    for (int i=0; i < E ; i++){
        line_t line_c = set_c.lines[i];
        if (evictionLRU > line_c.lru){
            evictionLRU = line_c.lru;
            evictionLine = i;
        }
    }

    //cache eviction
    if(set_c.lines[evictionLine].valid){
        EvictionCount++;
    }

    LRUCounter++;
    set_c.lines[evictionLine].valid=1;
    set_c.lines[evictionLine].tag=tag;
    set_c.lines[evictionLine].lru=LRUCounter;
}

//deallocate dynamic allocation
void FreeCache(){
    for(int i=0; i<S;i++){
        free(cache.sets[i].lines);
    }
    free(cache.sets);
}

int main(int argc, char* argv[])
{
    // parsing arguments
    char c;
    while ((c = getopt(argc, argv, "s:E:b:t:"))!=-1){
        switch(c){
            case 's':
                s_bit=atoi(optarg);
                S=(unsigned int)pow(2,s_bit);
                break;
            case 'E':
                E=atoi(optarg);
                break;
            case 'b':
                b_bit=atoi(optarg);
                B=(unsigned int)pow(2,b_bit);
                break;
            case 't':
                TraceFile=optarg;
                break;
            default:
                return 1;
        }
    } 
    //invalid operations
    if (s_bit==0||E==0||b_bit==0||TraceFile==NULL){
        return 1;
    }

    InitCache();
    ParseTrace();
    FreeCache();
    //final result
    printSummary(HitCount, MissCount, EvictionCount);
    return 0;
}
