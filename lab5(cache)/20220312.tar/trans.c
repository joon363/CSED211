/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */


/* 20220312 Junhyeok Park */
void transpose_32(int M, int N, int A[N][M], int B[M][N])
{
    int i,j,k;
    for(i=0; i<M; i+=8)
    {
        for(j=0; j<N; j+=8)
        {
            for(k=0;k<8;k++){
                B[j+0][i+k]=A[i+k][j+0];
                B[j+1][i+k]=A[i+k][j+1];
                B[j+2][i+k]=A[i+k][j+2];
                B[j+3][i+k]=A[i+k][j+3];
                B[j+4][i+k]=A[i+k][j+4];
                B[j+5][i+k]=A[i+k][j+5];
                B[j+6][i+k]=A[i+k][j+6];
                B[j+7][i+k]=A[i+k][j+7];
            }
        }

    }
}

void transpose_32_v2(int M, int N, int A[N][M], int B[M][N])
{
    int i,j,k;
    for(i=0; i<M; i+=8)
    {
        for(j=0; j<N; j+=8)
        {
            for(k=0;k<8;k++){
                int temp1=A[i+k][j+0];
                int temp2=A[i+k][j+1];
                int temp3=A[i+k][j+2];
                int temp4=A[i+k][j+3];
                int temp5=A[i+k][j+4];
                int temp6=A[i+k][j+5];
                int temp7=A[i+k][j+6];
                int temp8=A[i+k][j+7];
                
                B[j+0][i+k]=temp1;
                B[j+1][i+k]=temp2;
                B[j+2][i+k]=temp3;
                B[j+3][i+k]=temp4;
                B[j+4][i+k]=temp5;
                B[j+5][i+k]=temp6;
                B[j+6][i+k]=temp7;
                B[j+7][i+k]=temp8;
            }
        }
    }
}

void transpose_64(int M, int N, int A[N][M], int B[M][N]){
    int r, blockSize, c;
    int temp1, temp2, temp3, temp4, temp5, temp6, temp7, temp8; 
    int temp9, temp10, temp11, temp12, temp13, temp14, temp15, temp16;

    blockSize = 4;
    for(r = 0; r < N; r += blockSize)
    {
        for(c = 0; c < M; c += blockSize)
        {
            temp1 = A[r+0][c+3];
            temp2 = A[r+1][c+3];
            temp3 = A[r+2][c+3];
            temp4 = A[r+0][c+2];
            temp5 = A[r+1][c+2];
            temp6 = A[r+2][c+2];
            temp7 = A[r+0][c+1];
            temp8 = A[r+1][c+1];
            temp9 = A[r+2][c+1];
            temp10 = A[r+0][c+0];
            temp11 = A[r+1][c+0];
            temp12 = A[r+2][c+0];
            temp13 = A[r+3][c+0];
            temp14 = A[r+3][c+1];
            temp15 = A[r+3][c+2];
            temp16 = A[r+3][c+3];

            B[c+3][r+0] = temp1;
            B[c+3][r+1] = temp2;
            B[c+3][r+2] = temp3;
            B[c+2][r+0] = temp4;
            B[c+2][r+1] = temp5;
            B[c+2][r+2] = temp6;
            B[c+1][r+0] = temp7;
            B[c+1][r+1] = temp8;
            B[c+1][r+2] = temp9;
            B[c+0][r+0] = temp10;
            B[c+0][r+1] = temp11;
            B[c+0][r+2] = temp12;
            B[c+0][r+3] = temp13;
            B[c+1][r+3] = temp14;
            B[c+2][r+3] = temp15;
            B[c+3][r+3] = temp16;
        }
    }
}

void transpose_61(int b, int M, int N, int A[N][M], int B[M][N]){
    int i,j,p,q;
    int blocksize=b;
    for(i=0; i<M; i+=blocksize)
    {
        for(j=0; j<N; j+=blocksize)
        {
            for(p=i; p<(i+blocksize) && (p<M); p++)
            {
                for(q=j; q<(j+blocksize) && q<N; q++)
                {
                    B[p][q]=A[q][p];
                }
            }
        }
    }
}
char transpose_61_v1_desc[] = "61 v1"; //2425
void transpose_61_v1(int M, int N, int A[N][M], int B[M][N]){
    transpose_61(4,M,N,A,B);
}
char transpose_61_v2_desc[] = "61 v2"; //2215
void transpose_61_v2(int M, int N, int A[N][M], int B[M][N]){
    transpose_61(8,M,N,A,B);
}
char transpose_61_v3_desc[] = "61 v3"; //2088
void transpose_61_v3(int M, int N, int A[N][M], int B[M][N]){
    transpose_61(12,M,N,A,B);
}
char transpose_61_v4_desc[] = "61 v4"; //2002
void transpose_61_v4(int M, int N, int A[N][M], int B[M][N]){
    transpose_61(16,M,N,A,B);
}
char transpose_61_v5_desc[] = "61 v5"; //1970
void transpose_61_v5(int M, int N, int A[N][M], int B[M][N]){
    transpose_61(17,M,N,A,B);
}
char transpose_61_v6_desc[] = "61 v6"; //1970
void transpose_61_v6(int M, int N, int A[N][M], int B[M][N]){
    transpose_61(18,M,N,A,B);
}
char transpose_61_v7_desc[] = "61 v7"; //1983
void transpose_61_v7(int M, int N, int A[N][M], int B[M][N]){
    transpose_61(19,M,N,A,B);
}
char transpose_61_v8_desc[] = "61 v8"; //1984
void transpose_61_v8(int M, int N, int A[N][M], int B[M][N]){
    transpose_61(20,M,N,A,B);
}
char transpose_61_v9_desc[] = "61 v9"; //3856
void transpose_61_v9(int M, int N, int A[N][M], int B[M][N]){
    transpose_61(32,M,N,A,B);
}


char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
    switch(M){
        case 32:
            transpose_32_v2(M,N,A,B);
            break;
        case 64:
            transpose_64(M,N,A,B);
            break;
        case 61:
            transpose_61_v6(M,N,A,B);
            break;
    }
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 



/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
    //registerTransFunction(transpose_61_v1, transpose_61_v1_desc);
    //registerTransFunction(transpose_61_v2, transpose_61_v2_desc);
    //registerTransFunction(transpose_61_v3, transpose_61_v3_desc);
    //registerTransFunction(transpose_61_v4, transpose_61_v4_desc);
    //registerTransFunction(transpose_61_v5, transpose_61_v5_desc);
    //registerTransFunction(transpose_61_v6, transpose_61_v6_desc);
    //registerTransFunction(transpose_61_v7, transpose_61_v7_desc);
    //registerTransFunction(transpose_61_v8, transpose_61_v8_desc);
    //registerTransFunction(transpose_61_v9, transpose_61_v9_desc);

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

